---------------------------------------------------------------------------
--- Utilities to sort and arrange data.
--
-- @utillib gears.sort
---------------------------------------------------------------------------

return {
    topological = require("gears.sort.topological")
}
